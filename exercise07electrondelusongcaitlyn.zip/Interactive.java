public interface Interactive {
    void interact();
}
