public class Main {
public static void main(String[] args) {
        Location basement = new Location("Cave Basement", "Instant Fish Noodles");
        Trainer katchem = new Trainer("Katchem");
        GrassType cockroach = new GrassType("Flying Cockroach", 100, 200);
        NPC bear = new NPC("Bear");

        katchem.inspect(bear);
        katchem.inspect(basement); 
        katchem.inspect(cockroach);
    }
}
