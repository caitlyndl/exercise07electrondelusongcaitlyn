public class GrassType extends Monster {
  
  public GrassType (String name, int hp, int base) {
    super(name, "grass", "water", "fire", hp, base);
    atk = base;
    def = base;
   
  }
  @Override
  public void special() {
      System.out.println(name + " did a pose.");
  }
  
}